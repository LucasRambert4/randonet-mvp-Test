// index.tsx

import React from 'react';
import {
  ScrollView,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useNavigation, useRoute } from '@react-navigation/native';
import { useAuth } from '../../context/AuthContext';
import useSaveActivityLogic from './SaveActivityScreen.logic';
import { SaveActivityRouteParams } from './SaveActivityScreen.types';
import styles from './SaveActivityScreen.styles';

export default function SaveActivityScreen() {
  const navigation = useNavigation();
  const routeParams = useRoute().params as SaveActivityRouteParams;
  const { user } = useAuth();

  const {
    t,
    title,
    setTitle,
    description,
    setDescription,
    rating,
    setRating,
    type,
    setType,
    difficulty,
    setDifficulty,
    save,
  } = useSaveActivityLogic(user, routeParams, navigation);

  return (
    <ScrollView contentContainerStyle={styles.container}>
      <Text style={styles.label}>{t('saveActivity.labelTitle')}</Text>
      <TextInput
        placeholder={t('saveActivity.placeholderTitle')}
        style={styles.input}
        value={title}
        onChangeText={setTitle}
      />

      <Text style={styles.label}>{t('saveActivity.labelDescription')}</Text>
      <TextInput
        placeholder={t('saveActivity.placeholderDescription')}
        style={[styles.input, styles.multiline]}
        value={description}
        onChangeText={setDescription}
        multiline
      />

      <Text style={styles.label}>{t('saveActivity.labelRating')}</Text>
      <View style={styles.row}>
        {[1, 2, 3].map((i) => (
          <TouchableOpacity key={i} onPress={() => setRating(i)}>
            <Ionicons
              name={i <= rating ? 'star' : 'star-outline'}
              size={24}
              color="gold"
            />
          </TouchableOpacity>
        ))}
      </View>

      <Text style={styles.label}>{t('saveActivity.labelType')}</Text>
      <View style={styles.row}>
        {(['running', 'hiking', 'biking'] as const).map((tpe) => (
          <TouchableOpacity
            key={tpe}
            onPress={() => setType(tpe)}
            style={[styles.chip, type === tpe && styles.activeChip]}
          >
            <Text style={styles.chipText}>{t(`saveActivity.type${tpe}`)}</Text>
          </TouchableOpacity>
        ))}
      </View>

      <Text style={styles.label}>{t('saveActivity.labelDifficulty')}</Text>
      <View style={styles.row}>
        {(['easy', 'normal', 'hard'] as const).map((d) => (
          <TouchableOpacity
            key={d}
            onPress={() => setDifficulty(d)}
            style={[styles.chip, difficulty === d && styles.activeChip]}
          >
            <Text style={styles.chipText}>
              {t(
                `saveActivity.difficulty${
                  d.charAt(0).toUpperCase() + d.slice(1)
                }`
              )}
            </Text>
          </TouchableOpacity>
        ))}
      </View>

      <TouchableOpacity onPress={save} style={styles.saveBtn}>
        <Text style={styles.saveText}>{t('saveActivity.buttonSave')}</Text>
      </TouchableOpacity>
    </ScrollView>
  );
}
