// screens/SaveActivity/SaveActivityScreen.logic.ts

import { useState, useEffect } from 'react';
import { Alert } from 'react-native';
import * as FileSystem from 'expo-file-system';
import { supabase } from '../../../supabase-config';
import { useTranslation } from 'react-i18next';
import { SaveActivityRouteParams } from './SaveActivityScreen.types';

export default function useSaveActivityLogic(
  user: any,
  routeParams: SaveActivityRouteParams,
  navigation: any
) {
  const { t } = useTranslation();

  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [rating, setRating] = useState(0);
  const [type, setType] = useState<'hiking' | 'running' | 'biking'>('running');
  const [difficulty, setDifficulty] = useState<'easy' | 'normal' | 'hard'>(
    'normal'
  );

  useEffect(() => {
    if (routeParams.existingData) {
      const d = routeParams.existingData;
      setTitle(d.title || '');
      setDescription(d.description || '');
      setRating(d.rating || 0);
      setType(d.type || 'running');
      setDifficulty(d.difficulty || 'normal');
    }
  }, []);

  const save = async () => {
    if (!user) {
      Alert.alert(
        t('saveActivity.errorTitle'),
        t('saveActivity.errorNotLoggedIn')
      );
      return;
    }

    if (!routeParams.activityId) {
      Alert.alert('Error', 'No activityId found — cannot overwrite');
      return;
    }

    try {
      const filename = routeParams.activityId;
      const path = `${user.id}/${filename}`;

      const duration =
        routeParams.startTime && routeParams.endTime
          ? Math.round(
              (+new Date(routeParams.endTime) -
                +new Date(routeParams.startTime)) /
                1000
            )
          : 0;

      const data = {
        id: routeParams.existingData?.id || undefined,
        user_id: user.id,
        start_time: routeParams.startTime?.toISOString(),
        end_time: routeParams.endTime.toISOString(),
        duration_seconds: duration,
        distance_meters: Math.round(routeParams.distance),
        path: routeParams.route,
        title,
        description,
        rating,
        type,
        difficulty,
        location: routeParams.location,
        elevation: Math.round(routeParams.elevation || 0),
        trail_id: routeParams.trailId || null,
      };

      const fileUri = FileSystem.cacheDirectory + filename;
      await FileSystem.writeAsStringAsync(fileUri, JSON.stringify(data), {
        encoding: FileSystem.EncodingType.UTF8,
      });

      const { error: uploadError } = await supabase.storage
        .from('activities')
        .upload(
          path,
          { uri: fileUri, type: 'application/json', name: filename } as any,
          { upsert: true, contentType: 'application/json' }
        );

      if (uploadError) throw uploadError;

      const { error: dbError } = await supabase
        .from('activities')
        .upsert([data], { onConflict: 'id' });

      if (dbError) throw dbError;

      Alert.alert(
        t('saveActivity.successTitle'),
        t('saveActivity.successMessage')
      );
      navigation.goBack();
    } catch (err: any) {
      Alert.alert(
        t('saveActivity.errorTitle'),
        err.message || t('saveActivity.errorSaveFailed')
      );
    }
  };

  return {
    t,
    title,
    setTitle,
    description,
    setDescription,
    rating,
    setRating,
    type,
    setType,
    difficulty,
    setDifficulty,
    save,
  };
}
