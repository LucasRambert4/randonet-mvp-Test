// screens/EditActivity/EditActivityScreen.tsx

import React from 'react';
import SaveActivityScreen from '../SaveActivity';
import { SaveActivityRouteParams } from '../SaveActivity/SaveActivityScreen.types';

type EditActivityScreenProps = {
  route: {
    params: SaveActivityRouteParams;
  };
  navigation: any;
};

export default function EditActivityScreen({
  route,
  navigation,
}: EditActivityScreenProps) {
  return <SaveActivityScreen route={route} navigation={navigation} />;
}
